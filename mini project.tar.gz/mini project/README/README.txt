TITLE:- Bignum Basic Calculator
NAME:- Roshan Nalawade
MIS:- 111507047

Description:

------>	My bignum basic calculator does the basic operations such as multiplication, addition, subtraction, division, modulus, 
	increment(on vars) etc. on infinitely long real numbers.

------> It can even store the numbers in variables(a,b,c,...,z) and perform operations on these variables.

------>	It can calculate even calculate values for infinitely long numbers given as input mathematical functions such as sin(), cos(),
	tan(), exp(), etc.

------>	It can also be used for base change operations from decimal to binary, octal, hexadecimal and also binary, octal, hexadecimal to
	decimal.

------> It can also calculate factorial of very large numbers which is not done by bc and even google search box do not support very large
	numbers whereas my calculator can.

------> It can also be used to check whether a given number is prime or not this is not available in bc.

------> It can also perform comparison operations.

------> even coamments are also supported eg./* this is comment*/  
